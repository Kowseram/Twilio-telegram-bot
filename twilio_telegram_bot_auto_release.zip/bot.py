
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from twilio.rest import Client

user_data = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Welcome! Please send your Twilio SID and Token:\nUse /sid <your_sid>\n/token <your_token>")

async def save_sid(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data[update.effective_user.id] = user_data.get(update.effective_user.id, {})
    user_data[update.effective_user.id]['sid'] = context.args[0]
    await update.message.reply_text("✅ SID saved!")

async def save_token(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data[update.effective_user.id] = user_data.get(update.effective_user.id, {})
    user_data[update.effective_user.id]['token'] = context.args[0]
    await update.message.reply_text("✅ Token saved!")

async def buy_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in user_data or 'sid' not in user_data[user_id] or 'token' not in user_data[user_id]:
        await update.message.reply_text("❗ Please provide your SID and Token first.")
        return

    if len(user_data[user_id].get('numbers', [])) >= 3:
        await update.message.reply_text("❌ You can only buy up to 3 numbers.")
        return

    sid = user_data[user_id]['sid']
    token = user_data[user_id]['token']
    area_code = context.args[0]

    client = Client(sid, token)
    numbers = client.available_phone_numbers("CA").local.list(area_code=area_code, limit=5)

    keyboard = []
    for num in numbers:
        keyboard.append([InlineKeyboardButton(f"Buy {num.phone_number}", callback_data=f"buy|{num.phone_number}")])

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Available Numbers:", reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split('|')

    user_id = query.from_user.id
    sid = user_data[user_id]['sid']
    token = user_data[user_id]['token']
    client = Client(sid, token)

    if data[0] == "buy":
        number = data[1]
        user_numbers = user_data[user_id].get('numbers', [])
        if len(user_numbers) >= 3:
            await query.edit_message_text("❌ Maximum 3 numbers allowed.")
            return

        bought = client.incoming_phone_numbers.create(phone_number=number)
        user_numbers.append({"sid": bought.sid, "phone_number": bought.phone_number})
        user_data[user_id]['numbers'] = user_numbers

        msg_buttons = [[InlineKeyboardButton(f"📩 Show Message for {bought.phone_number}", callback_data=f"showmsg|{bought.phone_number}|{bought.sid}")]]
        reply_markup = InlineKeyboardMarkup(msg_buttons)

        await query.edit_message_text(f"✅ Bought {number}", reply_markup=reply_markup)

    elif data[0] == "showmsg":
        phone = data[1]
        sid_to_release = data[2]
        messages = client.messages.list(to=phone, limit=5)
        text = f"📥 Messages for {phone}:

"
        for m in messages:
            text += f"From: {m.from_}\nText: {m.body}\n\n"
        if not messages:
            text += "No messages found."

        # Auto release the number after showing messages
        try:
            client.incoming_phone_numbers(sid_to_release).delete()
            text += "\n\n🗑️ Number auto-released."
        except Exception as e:
            text += f"\n\n⚠️ Failed to release number: {e}"

        await query.edit_message_text(text)

if __name__ == "__main__":
    TELEGRAM_BOT_TOKEN = "8085207042:AAGwgJSau7vYkVddjpPp0fsW3lY-LLRmHG8"
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("sid", save_sid))
    app.add_handler(CommandHandler("token", save_token))
    app.add_handler(CommandHandler("buy", buy_command))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.run_polling()
